﻿namespace Formularios
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtnombre = new TextBox();
            txtmonto = new TextBox();
            FechaSolicitudPicker = new DateTimePicker();
            btncancelar = new Button();
            btnenviar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 26);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 61);
            label2.Name = "label2";
            label2.Size = new Size(136, 20);
            label2.TabIndex = 1;
            label2.Text = "Monto del anticipo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 90);
            label3.Name = "label3";
            label3.Size = new Size(128, 20);
            label3.TabIndex = 2;
            label3.Text = "Fecha de solicitud";
            // 
            // txtnombre
            // 
            txtnombre.Location = new Point(162, 26);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(234, 27);
            txtnombre.TabIndex = 3;
            // 
            // txtmonto
            // 
            txtmonto.Location = new Point(162, 58);
            txtmonto.Name = "txtmonto";
            txtmonto.Size = new Size(234, 27);
            txtmonto.TabIndex = 4;
            // 
            // FechaSolicitudPicker
            // 
            FechaSolicitudPicker.Location = new Point(162, 91);
            FechaSolicitudPicker.Name = "FechaSolicitudPicker";
            FechaSolicitudPicker.Size = new Size(234, 27);
            FechaSolicitudPicker.TabIndex = 5;
            // 
            // btncancelar
            // 
            btncancelar.Location = new Point(302, 124);
            btncancelar.Name = "btncancelar";
            btncancelar.Size = new Size(94, 29);
            btncancelar.TabIndex = 6;
            btncancelar.Text = "Cancelar";
            btncancelar.UseVisualStyleBackColor = true;
            btncancelar.Click += btncancelar_Click;
            // 
            // btnenviar
            // 
            btnenviar.Location = new Point(202, 124);
            btnenviar.Name = "btnenviar";
            btnenviar.Size = new Size(94, 29);
            btnenviar.TabIndex = 7;
            btnenviar.Text = "Enviar";
            btnenviar.UseVisualStyleBackColor = true;
            btnenviar.Click += btnenviar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(424, 177);
            Controls.Add(btnenviar);
            Controls.Add(btncancelar);
            Controls.Add(FechaSolicitudPicker);
            Controls.Add(txtmonto);
            Controls.Add(txtnombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtnombre;
        private TextBox txtmonto;
        private DateTimePicker FechaSolicitudPicker;
        private Button btncancelar;
        private Button btnenviar;
    }
}
