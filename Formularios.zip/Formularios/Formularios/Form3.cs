﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btniniciosecion_Click(object sender, EventArgs e)
        {
            string usuario = txtnombre.Text;
            string contrasena = txtcontraseña.Text;

            if (usuario == "Roger" && contrasena == "roger123")
            {
                Form principalForm = new Form4();
                principalForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error de Autenticación");
            }
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
