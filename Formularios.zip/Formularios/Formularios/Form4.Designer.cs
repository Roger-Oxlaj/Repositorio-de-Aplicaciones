﻿namespace Formularios
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnanticipo = new Button();
            btnnomina = new Button();
            SuspendLayout();
            // 
            // btnanticipo
            // 
            btnanticipo.Location = new Point(35, 22);
            btnanticipo.Name = "btnanticipo";
            btnanticipo.Size = new Size(94, 52);
            btnanticipo.TabIndex = 0;
            btnanticipo.Text = "Anticipo quincenal";
            btnanticipo.UseVisualStyleBackColor = true;
            btnanticipo.Click += btnanticipo_Click;
            // 
            // btnnomina
            // 
            btnnomina.Location = new Point(35, 80);
            btnnomina.Name = "btnnomina";
            btnnomina.Size = new Size(94, 55);
            btnnomina.TabIndex = 1;
            btnnomina.Text = "Nomina mensual";
            btnnomina.UseVisualStyleBackColor = true;
            btnnomina.Click += btnnomina_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(164, 152);
            Controls.Add(btnnomina);
            Controls.Add(btnanticipo);
            Name = "Form4";
            Text = "v";
            ResumeLayout(false);
        }

        #endregion

        private Button btnanticipo;
        private Button btnnomina;
    }
}