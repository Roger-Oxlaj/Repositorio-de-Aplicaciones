﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            try
            {
                decimal salarioBase = decimal.Parse(txtsalario.Text);
                decimal horasExtras = decimal.Parse(txthorasextras.Text);
                decimal deducciones = decimal.Parse(txtdocumentacion.Text);

                decimal pagoHoraExtra = (salarioBase / 160) * 0.25m * horasExtras;

                decimal salarioNeto = salarioBase + pagoHoraExtra - deducciones;

                txtsalarioneto.Text = salarioNeto.ToString("C");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores válidos en todos los campos.", "Error de Formato");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
