namespace Formularios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnenviar_Click(object sender, EventArgs e)
        {
            string nombre = txtmonto.Text;
            string monto = txtmonto.Text;
            DateTime fecha = FechaSolicitudPicker.Value;

           

            MessageBox.Show($"Solicitud de anticipo enviada:\nNombre: {nombre}\nMonto: {monto}\nFecha: {fecha.ToShortDateString()}", "Confirmaci�n");
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            txtnombre.Clear();
            txtmonto.Clear();
            FechaSolicitudPicker.Value = DateTime.Now;
        }
    }
}
