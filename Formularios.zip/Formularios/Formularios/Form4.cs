﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnanticipo_Click(object sender, EventArgs e)
        {
            Form anticipoForm = new Form1();
            anticipoForm.Show();
        }

        private void btnnomina_Click(object sender, EventArgs e)
        {
            Form nominaForm = new Form2();
            nominaForm.Show();

        }
    }
}
