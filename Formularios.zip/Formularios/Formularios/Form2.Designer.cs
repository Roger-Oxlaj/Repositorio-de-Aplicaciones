﻿namespace Formularios
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtsalario = new TextBox();
            txthorasextras = new TextBox();
            txtdocumentacion = new TextBox();
            btncalcular = new Button();
            label4 = new Label();
            txtsalarioneto = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 0;
            label1.Text = "Salario base";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 41);
            label2.Name = "label2";
            label2.Size = new Size(91, 20);
            label2.TabIndex = 1;
            label2.Text = "Horas extras";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 72);
            label3.Name = "label3";
            label3.Size = new Size(128, 20);
            label3.TabIndex = 2;
            label3.Text = "Documentaciones";
            // 
            // txtsalario
            // 
            txtsalario.Location = new Point(148, 6);
            txtsalario.Name = "txtsalario";
            txtsalario.Size = new Size(125, 27);
            txtsalario.TabIndex = 3;
            // 
            // txthorasextras
            // 
            txthorasextras.Location = new Point(148, 39);
            txthorasextras.Name = "txthorasextras";
            txthorasextras.Size = new Size(125, 27);
            txthorasextras.TabIndex = 4;
            // 
            // txtdocumentacion
            // 
            txtdocumentacion.Location = new Point(148, 72);
            txtdocumentacion.Name = "txtdocumentacion";
            txtdocumentacion.Size = new Size(125, 27);
            txtdocumentacion.TabIndex = 5;
            // 
            // btncalcular
            // 
            btncalcular.Location = new Point(12, 142);
            btncalcular.Name = "btncalcular";
            btncalcular.Size = new Size(94, 55);
            btncalcular.TabIndex = 6;
            btncalcular.Text = "Calcular salario";
            btncalcular.UseVisualStyleBackColor = true;
            btncalcular.Click += btncalcular_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(165, 147);
            label4.Name = "label4";
            label4.Size = new Size(89, 20);
            label4.TabIndex = 8;
            label4.Text = "Salario neto";
            // 
            // txtsalarioneto
            // 
            txtsalarioneto.Location = new Point(148, 170);
            txtsalarioneto.Name = "txtsalarioneto";
            txtsalarioneto.Size = new Size(125, 27);
            txtsalarioneto.TabIndex = 9;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(279, 209);
            Controls.Add(txtsalarioneto);
            Controls.Add(label4);
            Controls.Add(btncalcular);
            Controls.Add(txtdocumentacion);
            Controls.Add(txthorasextras);
            Controls.Add(txtsalario);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtsalario;
        private TextBox txthorasextras;
        private TextBox txtdocumentacion;
        private Button btncalcular;
        private TextBox textBox4;
        private Label label4;
        private TextBox txtsalarioneto;
    }
}